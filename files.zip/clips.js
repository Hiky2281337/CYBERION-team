exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const nickname = event.queryStringParameters?.nickname;
  if (!nickname) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'nickname required' }) };
  }

  try {
    const res = await fetch(
      `https://api.allstar.gg/v1/highlights?faceit_nickname=${encodeURIComponent(nickname)}&limit=6`,
      { headers: { 'Accept': 'application/json', 'User-Agent': 'Mozilla/5.0' } }
    );

    if (!res.ok) throw new Error(`AllStar status: ${res.status}`);
    const data = await res.json();
    const items = data.data || data.highlights || data.items || data.clips || [];

    return { statusCode: 200, headers, body: JSON.stringify({ clips: items }) };
  } catch (e) {
    return { statusCode: 200, headers, body: JSON.stringify({ clips: [], error: e.message }) };
  }
};
