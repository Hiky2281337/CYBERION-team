const FACEIT_KEY = '17dbbfd6-a94c-4f4a-b95a-7d75ccb85e3e';

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const nickname = event.queryStringParameters?.nickname;
  if (!nickname) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'nickname required' }) };
  }

  try {
    // Step 1: get player info
    const playerRes = await fetch(
      `https://open.faceit.com/data/v4/players?nickname=${encodeURIComponent(nickname)}&game=cs2`,
      { headers: { 'Authorization': `Bearer ${FACEIT_KEY}`, 'Accept': 'application/json' } }
    );

    if (!playerRes.ok) {
      return { statusCode: playerRes.status, headers, body: JSON.stringify({ error: 'Player not found' }) };
    }

    const player = await playerRes.json();
    const pid   = player.player_id;
    const elo   = player.games?.cs2?.faceit_elo  || '—';
    const level = player.games?.cs2?.skill_level || '—';

    // Step 2: get lifetime stats
    const statsRes = await fetch(
      `https://open.faceit.com/data/v4/players/${pid}/stats/cs2`,
      { headers: { 'Authorization': `Bearer ${FACEIT_KEY}`, 'Accept': 'application/json' } }
    );

    const statsData = statsRes.ok ? await statsRes.json() : null;
    const lt = statsData?.lifetime || {};

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        pid, elo, level,
        kd:      lt['Average K/D Ratio']      || '—',
        hs:      lt['Average Headshots %']     ? lt['Average Headshots %'] + '%' : '—',
        wr:      lt['Win Rate %']              ? lt['Win Rate %'] + '%'           : '—',
        matches: lt['Matches']                 || '—',
        kpr:     lt['Average Kills']           || '—',
        streak:  lt['Longest Win Streak']      || '—',
      }),
    };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
